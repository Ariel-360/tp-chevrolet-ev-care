/* @ds-bundle: {"format":3,"namespace":"ChevroletEVCareDesignSystem_5d22bf","components":[{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Callout","sourcePath":"components/core/Callout.jsx"},{"name":"Card","sourcePath":"components/core/Card.jsx"},{"name":"Icon","sourcePath":"components/core/Icon.jsx"},{"name":"KpiStat","sourcePath":"components/core/KpiStat.jsx"},{"name":"ProgressRing","sourcePath":"components/dataviz/ProgressRing.jsx"}],"sourceHashes":{"components/core/Badge.jsx":"1f8e8558b6ad","components/core/Button.jsx":"561fc912953d","components/core/Callout.jsx":"30587cb2ebd1","components/core/Card.jsx":"22603e4d8fe4","components/core/Icon.jsx":"72260b265e2b","components/core/KpiStat.jsx":"7377eb9745c2","components/dataviz/ProgressRing.jsx":"054313e27d29","ui_kits/ev-care-app/screens.jsx":"050ea2e75ead"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.ChevroletEVCareDesignSystem_5d22bf = window.ChevroletEVCareDesignSystem_5d22bf || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Badge — pill label. tone: ev (green, default), gold, dark, neutral.
 */
function Badge({
  tone = "ev",
  children,
  style,
  ...rest
}) {
  const tones = {
    ev: {
      background: "var(--ev-soft)",
      color: "#0a5e3f"
    },
    gold: {
      background: "var(--gold-bg)",
      color: "#7a5e09"
    },
    dark: {
      background: "#222",
      color: "var(--gold)"
    },
    neutral: {
      background: "#eee",
      color: "var(--ink-soft)"
    }
  };
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: "inline-block",
      fontFamily: "var(--font-text)",
      fontWeight: 700,
      fontSize: "0.72rem",
      letterSpacing: "0.4px",
      padding: "3px 10px",
      borderRadius: "var(--r-pill)",
      ...tones[tone],
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Button — EV Care action button.
 * variant: primary (gold), success (ev green), dark (ink), ghost, outline.
 */
function Button({
  variant = "primary",
  size = "md",
  disabled = false,
  full = false,
  children,
  style,
  ...rest
}) {
  const sizes = {
    sm: {
      padding: "8px 14px",
      fontSize: "0.82rem"
    },
    md: {
      padding: "11px 20px",
      fontSize: "0.92rem"
    },
    lg: {
      padding: "14px 26px",
      fontSize: "1rem"
    }
  };
  const variants = {
    primary: {
      background: "var(--gold)",
      color: "#000",
      border: "1px solid var(--gold)"
    },
    success: {
      background: "var(--ev)",
      color: "#fff",
      border: "1px solid var(--ev)"
    },
    dark: {
      background: "var(--ink)",
      color: "var(--gold)",
      border: "1px solid var(--ink)"
    },
    ghost: {
      background: "transparent",
      color: "var(--ink)",
      border: "1px solid transparent"
    },
    outline: {
      background: "transparent",
      color: "var(--ink)",
      border: "1px solid var(--line)"
    }
  };
  return /*#__PURE__*/React.createElement("button", _extends({
    disabled: disabled,
    style: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      gap: "8px",
      fontFamily: "var(--font-text)",
      fontWeight: 700,
      lineHeight: 1,
      borderRadius: "var(--r-md)",
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? 0.45 : 1,
      width: full ? "100%" : "auto",
      transition: "transform var(--dur-fast) var(--ease), box-shadow var(--dur-fast) var(--ease), filter var(--dur-fast) var(--ease)",
      ...sizes[size],
      ...variants[variant],
      ...style
    },
    onMouseDown: e => !disabled && (e.currentTarget.style.transform = "scale(0.97)"),
    onMouseUp: e => e.currentTarget.style.transform = "",
    onMouseLeave: e => e.currentTarget.style.transform = ""
  }, rest), children);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Callout.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Callout — left-bordered note. tone: note (ev green), warn (gold).
 */
function Callout({
  tone = "note",
  children,
  style,
  ...rest
}) {
  const tones = {
    note: {
      background: "var(--ev-soft)",
      borderColor: "var(--ev)"
    },
    warn: {
      background: "#fff5e0",
      borderColor: "var(--gold)"
    }
  };
  const t = tones[tone];
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      background: t.background,
      borderLeft: `4px solid ${t.borderColor}`,
      padding: "12px 16px",
      borderRadius: "0 8px 8px 0",
      fontFamily: "var(--font-text)",
      fontSize: "0.92rem",
      color: "var(--ink-soft)",
      lineHeight: "var(--lh-base)",
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Callout });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Callout.jsx", error: String((e && e.message) || e) }); }

// components/core/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Card — surface container. variant: default, raised (hover-elevates), kpi (centered).
 * accent: adds a left border in the given color (e.g. "var(--gold)").
 */
function Card({
  variant = "default",
  accent,
  hover = false,
  children,
  style,
  ...rest
}) {
  const base = {
    background: variant === "kpi" ? "var(--paper)" : "#fafafa",
    border: "1px solid var(--line)",
    borderRadius: "var(--r-lg)",
    padding: "var(--sp-6)",
    boxShadow: variant === "raised" ? "var(--shadow-2)" : "var(--shadow-1)",
    textAlign: variant === "kpi" ? "center" : "left",
    transition: "transform var(--dur-fast) var(--ease), box-shadow var(--dur-fast) var(--ease)",
    ...(accent ? {
      borderLeft: `4px solid ${accent}`
    } : null)
  };
  const onEnter = e => {
    if (!hover) return;
    e.currentTarget.style.transform = "translateY(-2px)";
    e.currentTarget.style.boxShadow = "var(--shadow-2)";
  };
  const onLeave = e => {
    if (!hover) return;
    e.currentTarget.style.transform = "";
    e.currentTarget.style.boxShadow = base.boxShadow;
  };
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      ...base,
      ...style
    },
    onMouseEnter: onEnter,
    onMouseLeave: onLeave
  }, rest), children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Card.jsx", error: String((e && e.message) || e) }); }

// components/core/Icon.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Icon — renders a line icon from the EV Care sprite.
 * stroke:currentColor, so it inherits text color (use --gold / --ev for accents).
 */
function Icon({
  name,
  size = 22,
  color,
  sprite = "assets/icons/icons.svg",
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("svg", _extends({
    width: size,
    height: size,
    style: {
      flex: "0 0 auto",
      color,
      verticalAlign: "-0.18em",
      ...style
    },
    "aria-hidden": "true"
  }, rest), /*#__PURE__*/React.createElement("use", {
    href: `${sprite}#i-${name}`
  }));
}
Object.assign(__ds_scope, { Icon });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Icon.jsx", error: String((e && e.message) || e) }); }

// components/core/KpiStat.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * KpiStat — big display number + label. Number is gold by default ("hard data" feel).
 */
function KpiStat({
  value,
  label,
  color = "var(--gold)",
  align = "center",
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      textAlign: align,
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-display)",
      fontWeight: 800,
      fontSize: "1.9rem",
      lineHeight: 1,
      color
    }
  }, value), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-text)",
      fontSize: "0.78rem",
      color: "var(--mute)",
      marginTop: "4px"
    }
  }, label));
}
Object.assign(__ds_scope, { KpiStat });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/KpiStat.jsx", error: String((e && e.message) || e) }); }

// components/dataviz/ProgressRing.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * ProgressRing — circular score gauge. The signature EV Care "vehicle health" visual.
 * Track + gold/green progress arc with a centered value.
 */
function ProgressRing({
  value = 86,
  max = 100,
  size = 140,
  stroke = 12,
  color = "var(--ev)",
  track = "var(--line)",
  label,
  suffix = "",
  style,
  ...rest
}) {
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const pct = Math.max(0, Math.min(1, value / max));
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: "inline-flex",
      flexDirection: "column",
      alignItems: "center",
      gap: "8px",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("svg", {
    width: size,
    height: size,
    viewBox: `0 0 ${size} ${size}`,
    style: {
      transform: "rotate(-90deg)"
    }
  }, /*#__PURE__*/React.createElement("circle", {
    cx: size / 2,
    cy: size / 2,
    r: r,
    fill: "none",
    stroke: track,
    strokeWidth: stroke
  }), /*#__PURE__*/React.createElement("circle", {
    cx: size / 2,
    cy: size / 2,
    r: r,
    fill: "none",
    stroke: color,
    strokeWidth: stroke,
    strokeLinecap: "round",
    strokeDasharray: c,
    strokeDashoffset: c * (1 - pct),
    style: {
      transition: "stroke-dashoffset var(--dur-slow) var(--ease)"
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center",
      width: size,
      height: size
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-display)",
      fontWeight: 800,
      fontSize: size * 0.26,
      color: "var(--ink)",
      lineHeight: 1
    }
  }, value, suffix), label && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-text)",
      fontSize: "0.72rem",
      color: "var(--mute)",
      marginTop: "2px"
    }
  }, label)));
}
Object.assign(__ds_scope, { ProgressRing });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/dataviz/ProgressRing.jsx", error: String((e && e.message) || e) }); }

// ui_kits/ev-care-app/screens.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* Chevrolet EV Care — app UI kit screens. Loaded by index.html, mounted via window.EVCareApp. */
const {
  useState
} = React;
const DS = window.ChevroletEVCareDesignSystem_5d22bf;
const {
  Button,
  Badge,
  Card,
  KpiStat,
  Callout,
  Icon,
  ProgressRing
} = DS;
const SPRITE = "../../assets/icons/icons.svg";
const I = props => /*#__PURE__*/React.createElement(Icon, _extends({
  sprite: SPRITE
}, props));

/* ---------- shared chrome ---------- */
function StatusBar() {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      padding: "10px 20px 4px",
      fontFamily: "var(--font-display)",
      fontWeight: 700,
      fontSize: ".82rem",
      color: "var(--ink)"
    }
  }, /*#__PURE__*/React.createElement("span", null, "9:41"), /*#__PURE__*/React.createElement("span", {
    style: {
      display: "flex",
      gap: 5,
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement(I, {
    name: "bolt",
    size: 14
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: ".72rem"
    }
  }, "5G")));
}
function AppHeader({
  title,
  sub
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "8px 20px 14px",
      display: "flex",
      alignItems: "center",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/logo/ev-care-bowtie.svg",
    alt: "",
    style: {
      width: 40,
      height: 16
    }
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-display)",
      fontWeight: 800,
      fontSize: "1.15rem",
      lineHeight: 1
    }
  }, title), sub && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: ".74rem",
      color: "var(--mute)",
      marginTop: 2
    }
  }, sub)), /*#__PURE__*/React.createElement("div", {
    style: {
      marginLeft: "auto",
      position: "relative"
    }
  }, /*#__PURE__*/React.createElement(I, {
    name: "bell",
    size: 22,
    color: "var(--ink-soft)"
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      position: "absolute",
      top: -2,
      right: -2,
      width: 8,
      height: 8,
      borderRadius: "50%",
      background: "var(--ev)"
    }
  })));
}
function BottomNav({
  tab,
  setTab
}) {
  const items = [{
    id: "home",
    icon: "shield",
    label: "Salud"
  }, {
    id: "usage",
    icon: "chart-bar",
    label: "Uso"
  }, {
    id: "service",
    icon: "calendar",
    label: "Service"
  }, {
    id: "rewards",
    icon: "loop",
    label: "Loyalty"
  }];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      borderTop: "1px solid var(--line)",
      background: "var(--paper)",
      padding: "8px 6px 14px"
    }
  }, items.map(it => {
    const active = tab === it.id;
    return /*#__PURE__*/React.createElement("button", {
      key: it.id,
      onClick: () => setTab(it.id),
      style: {
        flex: 1,
        background: "none",
        border: "none",
        cursor: "pointer",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        gap: 4,
        color: active ? "var(--ink)" : "var(--mute)",
        fontFamily: "var(--font-text)",
        fontSize: ".68rem",
        fontWeight: 700
      }
    }, /*#__PURE__*/React.createElement(I, {
      name: it.icon,
      size: 22,
      color: active ? "var(--gold)" : "var(--mute)"
    }), it.label);
  }));
}

/* ---------- screens ---------- */
function HomeScreen({
  go
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "4px 20px 20px",
      display: "flex",
      flexDirection: "column",
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(Card, {
    variant: "kpi",
    style: {
      paddingTop: 24,
      paddingBottom: 24
    }
  }, /*#__PURE__*/React.createElement(ProgressRing, {
    value: 86,
    label: "Salud del veh\xEDculo",
    size: 150
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 10,
      fontSize: ".84rem",
      color: "var(--ink-soft)"
    }
  }, "Spark EUV \xB7 ", /*#__PURE__*/React.createElement("b", null, "12.480 km"), " \xB7 todo en regla")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(Card, {
    style: {
      padding: 16
    }
  }, /*#__PURE__*/React.createElement(I, {
    name: "battery",
    color: "var(--ev)"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-display)",
      fontWeight: 800,
      fontSize: "1.5rem",
      marginTop: 6
    }
  }, "72%"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: ".74rem",
      color: "var(--mute)"
    }
  }, "Carga \xB7 259 km")), /*#__PURE__*/React.createElement(Card, {
    style: {
      padding: 16
    }
  }, /*#__PURE__*/React.createElement(I, {
    name: "bolt",
    color: "var(--gold)"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-display)",
      fontWeight: 800,
      fontSize: "1.5rem",
      marginTop: 6
    }
  }, "94%"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: ".74rem",
      color: "var(--mute)"
    }
  }, "Eficiencia media"))), /*#__PURE__*/React.createElement(Card, {
    accent: "var(--gold)",
    hover: true,
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12,
      cursor: "pointer"
    },
    onClick: () => go("service")
  }, /*#__PURE__*/React.createElement(I, {
    name: "calendar",
    color: "var(--gold)",
    size: 26
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 700,
      fontSize: ".95rem"
    }
  }, "Pr\xF3ximo service en 18 d\xEDas"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: ".78rem",
      color: "var(--mute)"
    }
  }, "1er mantenimiento \xB7 garant\xEDa vigente")), /*#__PURE__*/React.createElement(Button, {
    size: "sm"
  }, "Agendar")), /*#__PURE__*/React.createElement(Callout, null, /*#__PURE__*/React.createElement("b", null, "Garant\xEDa a la vista:"), " tu pr\xF3xima inspecci\xF3n mantiene la cobertura de f\xE1brica activa."));
}
function UsageScreen() {
  const bars = [{
    d: "L",
    v: 42
  }, {
    d: "M",
    v: 58
  }, {
    d: "M",
    v: 35
  }, {
    d: "J",
    v: 70
  }, {
    d: "V",
    v: 64
  }, {
    d: "S",
    v: 28
  }, {
    d: "D",
    v: 15
  }];
  const max = 70;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "4px 20px 20px",
      display: "flex",
      flexDirection: "column",
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(Card, {
    variant: "kpi"
  }, /*#__PURE__*/React.createElement(KpiStat, {
    value: "328",
    label: "km esta semana"
  })), /*#__PURE__*/React.createElement(Card, {
    variant: "kpi"
  }, /*#__PURE__*/React.createElement(KpiStat, {
    value: "14,2",
    label: "kWh / 100km",
    color: "var(--ev)"
  }))), /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 700,
      marginBottom: 14,
      fontFamily: "var(--font-display)"
    }
  }, "Recorrido diario"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "flex-end",
      gap: 10,
      height: 130
    }
  }, bars.map((b, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      flex: 1,
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: "100%",
      height: `${b.v / max * 110}px`,
      background: i === 3 ? "var(--gold)" : "var(--ev)",
      borderRadius: 5
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: ".7rem",
      color: "var(--mute)"
    }
  }, b.d))))), /*#__PURE__*/React.createElement(Card, {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(I, {
    name: "star",
    color: "var(--gold)",
    size: 24
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 700,
      fontSize: ".92rem"
    }
  }, "H\xE1bitos de carga: excelentes"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: ".78rem",
      color: "var(--mute)"
    }
  }, "Carg\xE1s en horarios \xF3ptimos el 88% del tiempo")), /*#__PURE__*/React.createElement(Badge, null, "+12 pts")));
}
function ServiceScreen() {
  const [booked, setBooked] = useState(false);
  const days = Array.from({
    length: 30
  }, (_, i) => i + 1);
  const slot = 23;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "4px 20px 20px",
      display: "flex",
      flexDirection: "column",
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(Card, {
    variant: "raised",
    style: {
      background: "var(--ink)",
      border: "none",
      color: "#fff",
      textAlign: "center"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: ".74rem",
      letterSpacing: 1,
      textTransform: "uppercase",
      color: "var(--gold-soft)"
    }
  }, "Pr\xF3ximo service"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-display)",
      fontWeight: 800,
      fontSize: "2.6rem",
      color: "var(--gold)",
      lineHeight: 1.1
    }
  }, "18 d\xEDas"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: ".84rem",
      color: "#ddd"
    }
  }, "1er mantenimiento \xB7 15.000 km")), /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 700,
      marginBottom: 12,
      fontFamily: "var(--font-display)"
    }
  }, "Eleg\xED un turno \xB7 Julio"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(7,1fr)",
      gap: 6
    }
  }, days.map(d => {
    const sel = d === slot;
    return /*#__PURE__*/React.createElement("div", {
      key: d,
      style: {
        aspectRatio: "1",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        borderRadius: 8,
        fontSize: ".8rem",
        fontWeight: sel ? 800 : 500,
        background: sel ? "var(--ev)" : "transparent",
        color: sel ? "#fff" : "var(--ink-soft)",
        border: sel ? "none" : "1px solid var(--line)"
      }
    }, d);
  }))), booked ? /*#__PURE__*/React.createElement(Callout, null, /*#__PURE__*/React.createElement("b", null, /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      verticalAlign: "-4px"
    }
  }, /*#__PURE__*/React.createElement(I, {
    name: "check",
    color: "var(--ev)",
    size: 18
  })), " Turno confirmado"), " \u2014 mi\xE9rcoles 23/07, 10:30 hs en EV Experience Center CABA. Te enviamos el recordatorio.") : /*#__PURE__*/React.createElement(Button, {
    variant: "success",
    full: true,
    size: "lg",
    onClick: () => setBooked(true)
  }, "Confirmar turno \xB7 23/07 10:30"));
}
function RewardsScreen() {
  const items = [{
    icon: "shield",
    t: "Garantía siempre vigente",
    s: "3 services al día",
    done: true
  }, {
    icon: "users",
    t: "Referí a un amigo",
    s: "Beneficio en tu próximo service",
    done: true
  }, {
    icon: "star",
    t: "Conductor eficiente",
    s: "Top 10% de la red EV Care",
    done: true
  }, {
    icon: "loop",
    t: "Plan de recompra",
    s: "Disponible a los 24 meses",
    done: false
  }];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "4px 20px 20px",
      display: "flex",
      flexDirection: "column",
      gap: 14
    }
  }, /*#__PURE__*/React.createElement(Card, {
    variant: "kpi",
    style: {
      background: "var(--gold-bg)",
      border: "none"
    }
  }, /*#__PURE__*/React.createElement(KpiStat, {
    value: "640",
    label: "puntos EV Care"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: ".8rem",
      color: "#7a5e09",
      marginTop: 6
    }
  }, "Nivel Plata \xB7 160 pts para Oro")), items.map((it, i) => /*#__PURE__*/React.createElement(Card, {
    key: i,
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12,
      opacity: it.done ? 1 : 0.55
    }
  }, /*#__PURE__*/React.createElement(I, {
    name: it.icon,
    color: it.done ? "var(--ev)" : "var(--mute)",
    size: 24
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 700,
      fontSize: ".92rem"
    }
  }, it.t), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: ".76rem",
      color: "var(--mute)"
    }
  }, it.s)), it.done ? /*#__PURE__*/React.createElement(I, {
    name: "check",
    color: "var(--ev)"
  }) : /*#__PURE__*/React.createElement(Badge, {
    tone: "neutral"
  }, "pronto"))));
}

/* ---------- app shell ---------- */
function EVCareApp() {
  const [tab, setTab] = useState("home");
  const titles = {
    home: {
      t: "EV Care",
      s: "Spark EUV · Ariel"
    },
    usage: {
      t: "Reporte de uso",
      s: "Últimos 7 días"
    },
    service: {
      t: "Agenda de service",
      s: "Cronograma de fábrica"
    },
    rewards: {
      t: "Loyalty loop",
      s: "Beneficios y referidos"
    }
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      width: 390,
      height: 800,
      background: "var(--bg)",
      borderRadius: 44,
      boxShadow: "var(--shadow-2)",
      overflow: "hidden",
      display: "flex",
      flexDirection: "column",
      border: "10px solid #111"
    }
  }, /*#__PURE__*/React.createElement(StatusBar, null), /*#__PURE__*/React.createElement(AppHeader, {
    title: titles[tab].t,
    sub: titles[tab].s
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflowY: "auto"
    }
  }, tab === "home" && /*#__PURE__*/React.createElement(HomeScreen, {
    go: setTab
  }), tab === "usage" && /*#__PURE__*/React.createElement(UsageScreen, null), tab === "service" && /*#__PURE__*/React.createElement(ServiceScreen, null), tab === "rewards" && /*#__PURE__*/React.createElement(RewardsScreen, null)), /*#__PURE__*/React.createElement(BottomNav, {
    tab: tab,
    setTab: setTab
  }));
}
window.EVCareApp = EVCareApp;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/ev-care-app/screens.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Callout = __ds_scope.Callout;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.Icon = __ds_scope.Icon;

__ds_ns.KpiStat = __ds_scope.KpiStat;

__ds_ns.ProgressRing = __ds_scope.ProgressRing;

})();
