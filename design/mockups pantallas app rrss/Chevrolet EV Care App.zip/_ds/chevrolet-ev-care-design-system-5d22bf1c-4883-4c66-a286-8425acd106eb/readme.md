# Chevrolet EV Care — Design System

A sober, premium design system for **Chevrolet EV Care**: a 3-month digital-marketing
consultancy proposal for the **Chevrolet Spark EUV** (100% electric) in Argentina, angled on
**after-sales trust and loyalty** ("no vendemos un auto, vendemos tranquilidad de largo plazo").

The strategic insight that drives every visual and copy decision: in the Argentine EV market the
biggest barrier to purchase is **not price or range — it's distrust of after-sales service and
warranty**. Chevrolet is the only brand in its competitive set with a real, installed dealer +
service network. The brand turns that into its edge: **"EV Care."**

> **Language:** the brand operates in **Rioplatense Spanish (Argentina)**. All product copy is in
> Spanish — write UI strings, slides and mockups in Spanish.

## Sources

This system was distilled from the project repository (read it for deeper context — you may need access):

- **GitHub:** `Ariel-360/tp-chevrolet-ev-care` @ `main` — https://github.com/Ariel-360/tp-chevrolet-ev-care
  - `design/DESIGN.md` — the original design guide (principles, color usage, motion, app skeletons).
  - `design/tokens.css` — the single source of truth for color/type/spacing/motion (mirrored here).
  - `TP_Integrador_MarketingMTyO_Grupo31_Chevrolet.html` — the full web presentation: component
    patterns (nav, section-card, KPI cards, tables, FODA grid, funnel, gantt, callouts), the inline
    bowtie+bolt logo, and the line-icon sprite — all reproduced in this system.

Explore that repository to build richer, more faithful designs.

Author of the source work: Ariel Lescano · Universidad Tecnológica Nacional, 2026.

---

## CONTENT FUNDAMENTALS

- **Language & register:** Argentine Spanish, professional but direct. Uses *voseo* lightly in app
  UI ("Elegí un turno", "Cargás en horarios óptimos", "Referí a un amigo"). Documents/strategy copy
  lean to a more neutral professional Spanish.
- **Voice:** confident, evidence-led, honest. The deck explicitly includes a *"Lectura honesta"*
  (honest read) admitting where rivals win on paper — credibility over hype. Mirror that: don't
  oversell.
- **Person:** speaks as "nosotros" (the consultancy/brand) and addresses the customer as "vos/tu".
- **Casing:** sentence case for body and headings; **kickers in UPPERCASE** with letter-spacing,
  colored gold. KPI numbers are bold display type.
- **Tone words:** *respaldo, confianza, tranquilidad, posventa, garantía vigente, red, cuidado.*
  The emotional promise is peace of mind.
- **Emoji:** **never.** Emojis are explicitly banned and replaced by the line-icon set. (The only
  exception is the source README's GitHub headings — not part of the brand surface.)
- **Numbers:** always hard data with sources cited beneath (`.src` captions). Percentages, unit
  counts, prices in ARS/USD. Numbers read as "proof."
- **Examples of real copy:**
  - "Posicionar al Spark EUV como el eléctrico con la red de respaldo y posventa más confiable de Argentina."
  - "Garantía a la vista" · "Onboarding EV" · "Rating de Uso" · "Loyalty Loop".
  - "El cliente nunca se atrasa y la garantía queda siempre vigente."

---

## VISUAL FOUNDATIONS

- **Palette:** ink black `#0E0E0E` foundation; **gold `#C9A227`** as the *earned* accent (KPI
  numbers, totals, brand, active state — never large gold fills); **electric green `#19A974`** for
  everything after-sales / EV / success / the Loyalty Loop. Blue and violet are quiet data colors
  only. Page bg is a warm off-white `#F6F6F4`; cards are pure white.
- **Type:** **Space Grotesk** (geometric display) for h1/h2/kickers and **all numbers** (weight
  700–800 — "hard data" feel); **Inter** for body. Kickers uppercase, `--tracking-kicker` (1.5px),
  gold. Both load from Google Fonts.
- **Spacing & layout:** 4px base scale; content max-width 1040px, centered. Vertical rhythm = `--sp-6`
  between sections, `--sp-8` card padding.
- **Backgrounds:** mostly flat white cards on off-white. The **one** gradient is the cover:
  `linear-gradient(135deg,#0E0E0E,#1c1c1c,#262011)` (ink → warm dark gold). No textures, no patterns,
  no full-bleed photography in the system itself (the source uses real benchmark screenshots as
  evidence imagery — warm, neutral, documentary, not stylized).
- **Corners:** cards `--r-lg` (14px), controls `--r-md` (11px), pills `--r-pill` (30px).
- **Shadows:** only two — `--shadow-1` (0 1px 3px, cards) and `--shadow-2` (0 10px 30px, elevated /
  hover). Nothing heavier; "nada cheap."
- **Borders:** 1px `--line` (#E4E4E4) hairlines. Emphasis = a 4px **left** accent border in gold or
  green on a card (used sparingly for "Capa MARCA / MODELO" and callouts) — this is an intentional
  brand motif here, not the generic AI trope.
- **Callouts:** `note` = pale-green fill + green left border (insights); `warn` = pale-gold fill +
  gold left border (cautions). Rounded only on the right (`0 8px 8px 0`).
- **Cards:** flat `#fafafa` or white, hairline border, subtle shadow, 14px radius. KPI cards are
  white and centered with a big gold number.
- **Motion:** minimal and intentional. Smooth scroll; subtle reveals (opacity 0→1 + translateY
  12→0, `--dur-slow` `--ease`, once, ~60–80ms stagger). Hover lifts cards −2px to `--shadow-2`
  (`--dur-fast`). Press shrinks buttons to ~0.97 scale. **No** infinite loops, no aggressive
  parallax, no bounce. Always respect `prefers-reduced-motion`.
- **Easing:** `cubic-bezier(.22,.61,.36,1)` for everything.
- **Transparency/blur:** the sticky nav uses `rgba(14,14,14,.96)` + `backdrop-filter: blur(6px)`
  with a 2px gold bottom border. Used sparingly.

---

## ICONOGRAPHY

- **System:** a **custom line-icon set** (`assets/icons/icons.svg` sprite), built to replace all
  emoji. Stroke `currentColor`, **1.75px**, round caps/joins, `fill:none`, viewBox `0 0 24 24`,
  base size 22–24px. Monochrome — icons inherit context color; use `--gold` or `--ev` when they're
  an accent.
- **Coverage (26 icons):** target, bank, car, image, plus, alert, rocket, cloud, city, users,
  building, search, mobile, megaphone, mail, loop, check, calendar, battery (with bolt), shield
  (-check), star, chart-bar, chart-line, bolt, bell, pin.
- **Usage:** `<svg class="ico"><use href="assets/icons/icons.svg#i-calendar"/></svg>` in plain
  HTML, or the `<Icon name="calendar" />` React component (set `sprite` to the correct relative path).
- **Emoji:** never. **Unicode** is used only for the star glyph in ratings ("4,5★") and the nav
  caret "▸".
- **Logo:** the brand mark is a **gold Chevrolet-style bowtie with an electric-green lightning
  bolt** through it — `assets/logo/ev-care-bowtie.svg` (and `-dark.svg` for dark panels). Reuse it
  as the project mark across pieces and apps. *(This is an academic project mark, not the official
  Chevrolet corporate logo.)*

---

## Index / manifest

**Root**
- `styles.css` — entry point (consumers link this). `@import`s only.
- `tokens/` — `colors.css`, `typography.css`, `spacing.css`, `motion.css`, `fonts.css`.
- `assets/` — `logo/` (bowtie SVGs), `icons/icons.svg` (line-icon sprite).
- `readme.md` — this guide. `SKILL.md` — Agent-Skills wrapper.

**Components** (`components/`) — namespace `window.ChevroletEVCareDesignSystem_5d22bf`
- `core/` — `Button`, `Badge`, `Card`, `KpiStat`, `Callout`, `Icon`.
- `dataviz/` — `ProgressRing` (the signature vehicle-health gauge).

**UI kits** (`ui_kits/`)
- `ev-care-app/` — interactive EV Care mobile app: vehicle-health home, usage report, service
  agenda (book a slot), and loyalty/achievements, with bottom-nav navigation. Also a Starting Point.

**Foundation cards** (`guidelines/`) — specimen cards for the Design System tab (Colors, Type,
Spacing, Brand groups).

---

### Notes / substitutions
- **Fonts** are loaded via Google Fonts `@import` (Space Grotesk + Inter) rather than self-hosted
  `@font-face` binaries — these *are* the brand fonts, not substitutions. For fully offline use
  (e.g. PDF export), self-host the woff2 files or accept the system-font fallback already in the
  stacks.
