/* Chevrolet EV Care — piezas sociales. Exporta a window. */
const DSx = window.ChevroletEVCareDesignSystem_5d22bf;
const { Icon } = DSx;
const SPR = "assets/icons/icons.svg";
const Li = (props) => <Icon sprite={SPR} {...props} />;
const PHOTO = "assets/spark.avif";
const PHOTO_HERO = "assets/spark-retail.avif";
const LOGO = "assets/logo/ev-care-bowtie.svg";
const LOGO_D = "assets/logo/ev-care-bowtie-dark.svg";

const DISP = "var(--font-display)";
const TEXT = "var(--font-text)";

/* small brand bits */
const Pill = ({ children, bg = "var(--gold)", color = "#000" }) => (
  <span style={{ display: "inline-flex", alignItems: "center", gap: 12, background: bg, color,
    fontFamily: TEXT, fontWeight: 700, fontSize: 26, letterSpacing: 3, textTransform: "uppercase",
    padding: "14px 26px", borderRadius: 40 }}>{children}</span>
);

const Handle = ({ dark }) => (
  <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
    <img src={dark ? LOGO_D : LOGO} alt="EV Care" style={{ height: 38, borderRadius: dark ? 6 : 0 }} />
    <span style={{ fontFamily: DISP, fontWeight: 700, fontSize: 28, color: dark ? "#fff" : "var(--ink)", letterSpacing: .5 }}>EV Care</span>
  </div>
);

/* ============ A · REEL "Mito vs Realidad" 1080×1920 ============ */
function Reel() {
  return (
    <div style={{ width: 1080, height: 1920, background: "#0E0E0E", position: "relative", overflow: "hidden", fontFamily: TEXT }}>
      {/* full-bleed photo */}
      <img src={PHOTO_HERO} alt="Chevrolet Spark EUV" style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "cover", objectPosition: "52% center" }} />
      {/* scrims */}
      <div style={{ position: "absolute", inset: 0, background: "linear-gradient(180deg, rgba(14,14,14,.72) 0%, rgba(14,14,14,.25) 26%, rgba(14,14,14,0) 46%, rgba(14,14,14,.35) 68%, rgba(14,14,14,.96) 100%)" }}></div>

      {/* top */}
      <div style={{ position: "absolute", top: 64, left: 72, right: 72, display: "flex", alignItems: "center", justifyContent: "space-between", zIndex: 3 }}>
        <Handle dark />
        <span style={{ fontFamily: DISP, fontWeight: 700, fontSize: 24, letterSpacing: 4, color: "rgba(255,255,255,.7)" }}>REEL</span>
      </div>

      <div style={{ position: "absolute", top: 170, left: 72, right: 72, display: "flex", flexDirection: "column", alignItems: "center", textAlign: "center", zIndex: 3 }}>
        <Pill>Mito <span style={{opacity:.55}}>vs</span> Realidad</Pill>
        <div style={{ fontFamily: DISP, fontWeight: 800, fontSize: 118, lineHeight: .96, color: "#fff", marginTop: 38, letterSpacing: -2, textShadow: "0 4px 30px rgba(0,0,0,.45)" }}>¿Y si se<br/>rompe?</div>
      </div>

      {/* play */}
      <div style={{ position: "absolute", top: 980, left: "50%", transform: "translateX(-50%)", zIndex: 4,
        width: 128, height: 128, borderRadius: "50%", background: "rgba(255,255,255,.16)", backdropFilter: "blur(6px)", border: "2px solid rgba(255,255,255,.4)", display: "flex", alignItems: "center", justifyContent: "center" }}>
        <div style={{ width: 0, height: 0, borderTop: "24px solid transparent", borderBottom: "24px solid transparent", borderLeft: "40px solid #fff", marginLeft: 10 }}></div>
      </div>

      {/* bottom answer */}
      <div style={{ position: "absolute", left: 0, right: 0, bottom: 0, padding: "0 80px 90px", zIndex: 3 }}>
        <span style={{ fontFamily: TEXT, fontWeight: 700, fontSize: 26, letterSpacing: 3, textTransform: "uppercase", color: "var(--gold-soft)" }}>La realidad</span>
        <div style={{ fontFamily: DISP, fontWeight: 800, fontSize: 100, lineHeight: .98, color: "var(--ev)", marginTop: 16, letterSpacing: -1 }}>Lo arreglamos<br/>nosotros.</div>
        <div style={{ fontFamily: TEXT, fontSize: 34, color: "#dedbd4", marginTop: 26, lineHeight: 1.4, maxWidth: 800 }}>
          La única red de posventa oficial Chevrolet instalada en todo el país. Tu garantía, siempre vigente.
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 16, marginTop: 40 }}>
          <Li name="shield" size={40} color="var(--ev)" />
          <span style={{ fontFamily: DISP, fontWeight: 700, fontSize: 30, color: "#fff" }}>Chevrolet EV Care</span>
        </div>
      </div>
    </div>
  );
}

/* ============ B · POST POSVENTA 1080×1350 ============ */
function PostPosventa() {
  const rows = [
    { icon: "calendar", t: "Agendá tu service online", s: "Elegí día y horario en segundos" },
    { icon: "chart-bar", t: "Reporte de uso mensual", s: "Autonomía, eficiencia y hábitos de carga" },
    { icon: "star", t: "Rating de tu vehículo", s: "Conocé la salud real de tu Spark EUV" },
  ];
  return (
    <div style={{ width: 1080, height: 1350, background: "var(--bg)", position: "relative", overflow: "hidden", fontFamily: TEXT, display: "flex", flexDirection: "column" }}>
      {/* gold header */}
      <div style={{ background: "var(--gold)", padding: "56px 72px 52px", display: "flex", alignItems: "center", gap: 22 }}>
        <img src={LOGO_D} alt="EV Care" style={{ height: 56, borderRadius: 8 }} />
        <div>
          <div style={{ fontFamily: DISP, fontWeight: 800, fontSize: 50, color: "#0E0E0E", letterSpacing: 1, lineHeight: 1 }}>EV CARE</div>
          <div style={{ fontFamily: TEXT, fontWeight: 600, fontSize: 30, color: "#3a2f08", marginTop: 8 }}>Tu auto, siempre al día</div>
        </div>
      </div>

      {/* rows */}
      <div style={{ padding: "20px 72px 8px", display: "flex", flexDirection: "column" }}>
        {rows.map((r, i) => (
          <div key={i} style={{ display: "flex", alignItems: "center", gap: 30, padding: "34px 0",
            borderBottom: i < rows.length - 1 ? "1px solid var(--line)" : "none" }}>
            <div style={{ width: 92, height: 92, borderRadius: 22, flex: "0 0 auto", background: "var(--ev-soft)", display: "flex", alignItems: "center", justifyContent: "center" }}>
              <Li name={r.icon} size={46} color="var(--ev)" />
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ fontFamily: DISP, fontWeight: 700, fontSize: 40, color: "var(--ink)", lineHeight: 1.05 }}>{r.t}</div>
              <div style={{ fontFamily: TEXT, fontSize: 28, color: "var(--mute)", marginTop: 8 }}>{r.s}</div>
            </div>
            <span style={{ fontFamily: DISP, fontSize: 44, color: "var(--gold)", fontWeight: 700 }}>›</span>
          </div>
        ))}
      </div>

      {/* photo hero */}
      <div style={{ flex: 1, position: "relative", marginTop: 8, overflow: "hidden" }}>
        <img src={PHOTO_HERO} alt="Chevrolet Spark EUV" style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "cover", objectPosition: "center 42%" }} />
        <div style={{ position: "absolute", inset: 0, background: "linear-gradient(180deg, rgba(14,14,14,0) 55%, rgba(14,14,14,.55) 100%)" }}></div>
        <div style={{ position: "absolute", left: 72, bottom: 56, zIndex: 2 }}>
          <Pill bg="var(--ink)" color="var(--gold)">Spark EUV · 100% eléctrico</Pill>
        </div>
      </div>
    </div>
  );
}

/* ============ C · SEARCH AD 1080×1080 ============ */
function SearchAd() {
  const sitelinks = [
    { t: "Test drive", s: "Reservá online" },
    { t: "Garantía", s: "Cobertura de fábrica" },
    { t: "Concesionarios", s: "Red oficial en todo el país" },
  ];
  return (
    <div style={{ width: 1080, height: 1080, background: "#F6F6F4", position: "relative", overflow: "hidden", fontFamily: TEXT }}>
      <div style={{ position: "absolute", top: 56, left: 56, right: 56, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <Handle />
        <span style={{ fontFamily: TEXT, fontWeight: 700, fontSize: 24, letterSpacing: 3, textTransform: "uppercase", color: "var(--mute)" }}>Search Ad</span>
      </div>

      {/* search bar */}
      <div style={{ position: "absolute", top: 150, left: 56, right: 56, background: "#fff", border: "1px solid var(--line)", borderRadius: 50, padding: "20px 32px", display: "flex", alignItems: "center", gap: 20, boxShadow: "var(--shadow-1)" }}>
        <Li name="search" size={32} color="var(--mute)" />
        <span style={{ fontFamily: TEXT, fontSize: 29, color: "var(--ink-soft)" }}>service auto eléctrico chevrolet</span>
      </div>

      {/* ad card */}
      <div style={{ position: "absolute", top: 280, left: 56, right: 56, background: "#fff", border: "1px solid var(--line)", borderRadius: 20, padding: "36px 44px", boxShadow: "var(--shadow-2)" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 14, marginBottom: 18 }}>
          <span style={{ fontFamily: TEXT, fontWeight: 700, fontSize: 24, color: "var(--ink)" }}>Patrocinado</span>
          <div style={{ width: 48, height: 48, borderRadius: "50%", background: "var(--ink)", display: "flex", alignItems: "center", justifyContent: "center" }}>
            <img src={LOGO_D} alt="" style={{ width: 34, borderRadius: 4 }} />
          </div>
          <div style={{ lineHeight: 1.2 }}>
            <div style={{ fontFamily: TEXT, fontWeight: 600, fontSize: 23, color: "var(--ink)" }}>Chevrolet Argentina</div>
            <div style={{ fontFamily: TEXT, fontSize: 22, color: "var(--ev)" }}>chevrolet.com.ar/ev-care</div>
          </div>
        </div>

        <div style={{ fontFamily: DISP, fontWeight: 700, fontSize: 40, color: "#1F6FBF", lineHeight: 1.12 }}>
          Chevrolet Spark EUV | Service Oficial
        </div>
        <div style={{ fontFamily: TEXT, fontSize: 27, color: "var(--ink-soft)", lineHeight: 1.4, marginTop: 14 }}>
          El eléctrico con la red de posventa más grande del país. Agendá tu test drive.
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 22, marginTop: 24, paddingTop: 22, borderTop: "1px solid var(--line)" }}>
          {sitelinks.map((s, i) => (
            <div key={i}>
              <div style={{ fontFamily: TEXT, fontWeight: 700, fontSize: 25, color: "#1F6FBF" }}>{s.t}</div>
              <div style={{ fontFamily: TEXT, fontSize: 21, color: "var(--mute)", marginTop: 5, lineHeight: 1.3 }}>{s.s}</div>
            </div>
          ))}
        </div>
      </div>

      <div style={{ position: "absolute", bottom: 56, left: 56, display: "flex", alignItems: "center", gap: 14, color: "var(--mute)", fontFamily: TEXT, fontSize: 23 }}>
        <Li name="shield" size={30} color="var(--ev)" /> Respaldo y posventa Chevrolet EV Care
      </div>
    </div>
  );
}

/* ============ D · CARRUSEL "5 cosas" 1080×1350 ============ */
const TIPS = [
  { n: "01", icon: "bolt", t: "Carga inteligente", s: "Cargá en horarios óptimos y de noche: cuidás la vida útil de la batería y gastás menos." },
  { n: "02", icon: "shield", t: "Service en red oficial", s: "El único respaldo con red de posventa instalada en todo el país. Tu garantía, siempre vigente." },
  { n: "03", icon: "cloud", t: "Software al día", s: "Las actualizaciones mejoran autonomía, seguridad y rendimiento. Mantenelo siempre actualizado." },
  { n: "04", icon: "car", t: "Neumáticos y frenos", s: "El torque instantáneo desgasta distinto. Revisá neumáticos y frenos regenerativos a tiempo." },
  { n: "05", icon: "battery", t: "Chequeo de batería", s: "Un diagnóstico anual de salud de batería mantiene el rendimiento y la cobertura de fábrica." },
];

function CarouselCover() {
  return (
    <div style={{ width: 1080, height: 1350, background: "#0E0E0E", position: "relative", overflow: "hidden", fontFamily: TEXT }}>
      <img src={PHOTO_HERO} alt="Chevrolet Spark EUV" style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "cover", objectPosition: "56% center" }} />
      <div style={{ position: "absolute", inset: 0, background: "linear-gradient(180deg, rgba(14,14,14,.78) 0%, rgba(14,14,14,.35) 38%, rgba(14,14,14,.55) 70%, rgba(14,14,14,.95) 100%)" }}></div>
      <div style={{ position: "absolute", top: 72, left: 72, right: 72, display: "flex", alignItems: "center", justifyContent: "space-between", zIndex: 3 }}>
        <Handle dark />
        <span style={{ fontFamily: TEXT, fontWeight: 700, fontSize: 24, letterSpacing: 3, textTransform: "uppercase", color: "var(--gold-soft)" }}>Guía EV</span>
      </div>

      <div style={{ position: "absolute", bottom: 150, left: 72, right: 72, zIndex: 3 }}>
        <div style={{ fontFamily: DISP, fontWeight: 800, fontSize: 150, lineHeight: .9, color: "var(--gold)", letterSpacing: -3 }}>5</div>
        <div style={{ fontFamily: DISP, fontWeight: 800, fontSize: 76, lineHeight: 1.02, color: "#fff", marginTop: 12, letterSpacing: -1 }}>cosas que tu<br/>eléctrico necesita</div>
        <div style={{ fontFamily: TEXT, fontSize: 32, color: "#bdbab0", marginTop: 28, maxWidth: 720, lineHeight: 1.4 }}>
          Cuidados clave para que tu Spark EUV rinda más y conserve su garantía.
        </div>
      </div>

      <div style={{ position: "absolute", bottom: 56, left: 72, display: "flex", alignItems: "center", gap: 14, color: "#cfccc4", fontFamily: TEXT, fontSize: 28, fontWeight: 600, zIndex: 3 }}>
        Deslizá <span style={{ fontFamily: DISP, color: "var(--gold)", fontSize: 34 }}>→</span>
      </div>
    </div>
  );
}

function CarouselTip({ tip, last }) {
  return (
    <div style={{ width: 1080, height: 1350, background: "var(--bg)", position: "relative", overflow: "hidden", fontFamily: TEXT }}>
      <div style={{ position: "absolute", top: 64, left: 72, right: 72, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <Handle />
        <span style={{ fontFamily: DISP, fontWeight: 700, fontSize: 30, color: "var(--mute)" }}>{tip.n} / 05</span>
      </div>

      <div style={{ position: "absolute", top: 234, left: 72, right: 72 }}>
        <div style={{ width: 124, height: 124, borderRadius: 32, background: "var(--ev-soft)", display: "flex", alignItems: "center", justifyContent: "center" }}>
          <Li name={tip.icon} size={62} color="var(--ev)" />
        </div>
        <div style={{ fontFamily: DISP, fontWeight: 800, fontSize: 150, lineHeight: .85, color: "var(--gold)", marginTop: 46, letterSpacing: -4 }}>{tip.n}</div>
        <div style={{ fontFamily: DISP, fontWeight: 800, fontSize: 66, lineHeight: 1.02, color: "var(--ink)", marginTop: 22, letterSpacing: -1 }}>{tip.t}</div>
        <div style={{ fontFamily: TEXT, fontSize: 35, color: "var(--ink-soft)", marginTop: 26, lineHeight: 1.42, maxWidth: 880 }}>{tip.s}</div>
      </div>

      {last ? (
        <div style={{ position: "absolute", left: 72, right: 72, bottom: 64, background: "linear-gradient(150deg,#0E0E0E,#262011)", borderRadius: 24, padding: "38px 44px", display: "flex", alignItems: "center", gap: 28 }}>
          <div style={{ flex: 1 }}>
            <div style={{ fontFamily: TEXT, fontWeight: 700, fontSize: 23, letterSpacing: 3, textTransform: "uppercase", color: "var(--gold-soft)" }}>Empezá hoy</div>
            <div style={{ fontFamily: DISP, fontWeight: 800, fontSize: 50, color: "#fff", marginTop: 8, lineHeight: 1 }}>Agendá en EV Care</div>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 14, background: "var(--ev)", color: "#fff", fontFamily: TEXT, fontWeight: 700, fontSize: 30, padding: "22px 30px", borderRadius: 16, whiteSpace: "nowrap" }}>
            <Li name="calendar" size={34} /> Reservar
          </div>
        </div>
      ) : (
        <div style={{ position: "absolute", left: 72, bottom: 64, display: "flex", alignItems: "center", gap: 14, color: "var(--mute)", fontFamily: TEXT, fontSize: 28, fontWeight: 600 }}>
          Seguí <span style={{ fontFamily: DISP, color: "var(--gold)", fontSize: 34 }}>→</span>
        </div>
      )}
    </div>
  );
}

Object.assign(window, { Reel, PostPosventa, SearchAd, CarouselCover, CarouselTip, TIPS });
